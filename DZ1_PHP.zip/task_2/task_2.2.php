<?php
	$title = 'Главная страница - страница обо мне';
	$for_h1 = 'Информация обо мне';
	$year = date('Y');
	$img = "<img src='airplane.jpg'>";

	include "site.html";
