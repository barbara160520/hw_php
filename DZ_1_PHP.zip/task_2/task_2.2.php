<?php
	$title = 'Главная страница - страница обо мне';
	$for_h1 = 'Информация обо мне';
	$year = date('Y');
	$img = 'airplane.jpg';

	include "site_2.2.php";
