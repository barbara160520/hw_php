<?php
	$v1 = 1;
	$v2 = 2;
	echo "v1 = ".$v1."<br>"."v2 = ".$v2."<br><br>";

	/*
	$v1 += $v2;
	$v2 -= $v1;
	 */

	$v3 = $v2;
	$v2 = $v1;
	$v1 = $v3;

	echo "v1 = {$v1}<br>v2 = {$v2}<br><br>";
?>