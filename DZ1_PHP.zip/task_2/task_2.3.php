<?php
	$title = 'Главная страница - страница обо мне';
	$for_h1 = 'Информация обо мне';
	$year = date('Y');
	$img = "<img src='airplane.jpg'>";

	$content = file_get_contents('task_2.3.html');
	$content = str_replace('{{title}}', $title, $content);
	$content = str_replace('{{for_h1}}', $for_h1, $content);
	$content = str_replace('{{img}}', $img, $content);
	$content = str_replace('{{year}}', $year, $content);
	echo $content;
?>